﻿using InterfaceBooster.ProviderPluginApi;
using InterfaceBooster.ProviderPluginApi.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace $safeprojectname$.V1
{
    public class ProviderPluginInstance : IProviderPluginInstance
    {
        #region PROPERTIES

        public IHost Host { get; private set; }
        public IList<Question> ConnectionSettingQuestions { get; private set; }

        #endregion

        #region PUBLIC METHODS

        public ProviderPluginInstance(IHost host)
        {
            this.Host = host;
        }

        public IProviderConnection CreateProviderConnection(ConnectionSettings settings)
        {
            if (ValidateSettings(settings))
                throw new Exception("Invalid settings");

            return new ProviderConnection(settings);
        }

        #endregion

        #region INTERNAL METHODS

        private bool ValidateSettings(ConnectionSettings settings)
        {
            // check whether all setting values are valid

            return true;
        }

        #endregion
    }
}
