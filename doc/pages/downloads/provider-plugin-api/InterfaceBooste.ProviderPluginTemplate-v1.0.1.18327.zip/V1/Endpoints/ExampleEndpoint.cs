﻿using InterfaceBooster.ProviderPluginApi.Data;
using InterfaceBooster.ProviderPluginApi.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace $safeprojectname$.V1.Endpoints
{
    public class ExampleEndpoint : IReadEndpoint
    {
        #region PROPERTIES

        /*
         * The full path of this Endpoint is: 
         *      \\[ConnectionIdentifier]\Path\To\My\ExampleEndpoint
         */

        public string Name { get { return "ExampleEndpoint"; } }
        public string[] Path { get { return new string[] { "Path", "To", "My" }; } }

        public LocalizedText Description
        {
            get
            {
                return new LocalizedText("This is an example")
                    .Add("DE", "Das ist ein Beispiel")
                    .Add("FR", "Ceci est un exemple");
            }
        }

        #endregion

        public ReadResource GetReadResource()
        {
            throw new NotImplementedException();
        }

        public InterfaceBooster.ProviderPluginApi.Communication.ReadResponse RunReadRequest(InterfaceBooster.ProviderPluginApi.Communication.IReadRequest request)
        {
            throw new NotImplementedException();
        }
    }
}
